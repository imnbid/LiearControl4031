clc;
clear;

% Define the transfer functions G(s) and H(s)
G1 = tf([1], [1 0]);
G2 = tf([2 1], [1]);
G3 = tf([1], [1 0 1]);
G4 = tf([1 0], [1 1]);
H1 = tf([3], [1 0]);
H2 = tf([1 -1], [1 3]);
H3 = tf([1 0], [1 3 1]);
H4 = tf([1], [1 2]);

% Forward paths
P1 = G4 * G3;                 % Y2 -> Y5
P2 = G1 * G2 * G3;        % Y1 -> Y5

% Loop gains
L1 = -G1 * H1;
L2 = -G2 * G1 * G3 * H3;
L3 = -G3 * H2;
L4 = - H4;

% Non-touching loops (for simplicity, assume no non-touching loops here)
L11 = L4 * L1;
L12 = L1 * L3;
% Compute Δ (system determinant)
Delta = 1 - (L1 + L2 + L3 + L4) + (L11 + L12);

% Compute T1 = Y5(s)/Y2(s)
T1 = P1 / Delta;

% Compute T2 = Y5(s)/Y1(s)
T2 = P2 / Delta;

% Display the results
T1
T2

% Compute poles
poles_T1 = pole(T1)
poles_T2 = pole(T2)


