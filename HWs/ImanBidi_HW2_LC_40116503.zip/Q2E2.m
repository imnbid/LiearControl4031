clc
clear all 
close all

%%
s = tf('s');
hold on

%constants
kt = 1;
kb = 0.5;
f = 0.2;
j = 1 ;
ra = 2 ;
km = 0.8;
ka = 1 ;

%functions
G = (( km/ra )*1/( j*s + f ))/( 1 + ( km/ra )*( 1/( j*s + f ))*( kb + kt ));
G1 = (( km/ra )*1/( j*s+f ))/(1 + ( km/ra )*(1/( j*s+f ))*( kb ));

%%steps
step(G , 15);
step(G1 , 15);
legend
KinG = dcgain(G);
KinG1 = dcgain(G1);

%error funcs 
essinG = 1 / (1 + KinG);
essinG1 = 1 / (1 + KinG1);

%results
fprintf('Steady-State Error for G: %.4f\n', essinG);
fprintf('Steady-State Error for G1: %.4f\n', essinG1);