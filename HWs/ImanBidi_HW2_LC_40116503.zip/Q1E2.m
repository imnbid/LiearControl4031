clc
clear all 
close all

%%
s = tf('s');
hold on
wn = 4/(0.25*1.41);
zeeta = 0.25 ;
%%the equations
G = 1.58*(wn^2)/(s^2 + 2*zeeta*wn*s + wn^2);
G1 = 1.58*(wn^2)/(s^2 + 2*s*wn*zeeta + 0.58*wn^2);
G2 = 1.58*(wn^2)/(s^2 + 2*s*wn*zeeta - 0.58*wn^2);
%step the functions 
step (G , 5);step (G1 , 5);step (G2 , 5);