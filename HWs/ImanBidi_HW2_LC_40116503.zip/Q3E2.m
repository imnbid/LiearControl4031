clc
clear all 
close all

%%
s = tf('s');
hold on;
k = 5;%cons
G = k/( s^2+4*s+k );%func
step(G,10);%result